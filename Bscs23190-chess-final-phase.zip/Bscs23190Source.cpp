//#include "chess_board.h"
//#include "Header.h"
#include "Bscs23190chess.h"

int main() {
	chess_game h;
	h.start();
	/*
	board b;
	b.init();
	
	//b.init();
	//b.draw();
	//b.move();

	position p1,p2,p3,p4,p5,p6;
	p1.x = 7;
    p1.y = 1;
	p2.x = 4;
	p2.y = 4;
	b.update_board(p1, p2);
	p3.x = 0;
	p3.y = 3;
	p4.x = 2;
	p4.y = 2;
	b.update_board(p3, p4);
	p5.x = 1;
	p5.y = 1;
	p6.x = 2;
	p6.y = 4;
	b.update_board(p5, p6);
	*/
	SetClr(15, 0);
	//b.draw();*/
}