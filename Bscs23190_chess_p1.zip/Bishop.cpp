#include "Bishop.h"

Bishop::Bishop(position p, color c) :pieces(p, c) {
    if (c == BLACK) {
        sym = 'b';
    }
    else {
        sym = 'B';
    }
}