#include "Knight.h"


Knight::Knight(position p, color c) :pieces(p, c) {
    if (c == BLACK) {
        sym = 'h';
    }
    else {
        sym = 'H';
    }
}