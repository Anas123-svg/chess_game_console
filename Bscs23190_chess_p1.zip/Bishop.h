#pragma once
#ifndef BISHOP_H
#define BISHOP_H



#include "piece.h"
class Bishop :
    public pieces
{
public:
    Bishop(position p, color c);
};

#endif // !BISHOP_H