#include "chess_board.h"


int main() {
	board b;

	b.init();
	b.draw();
}