#include "Rook.h"



Rook::Rook(position p, color c) : pieces(p, c)
{
    if (c == BLACK) {
        sym = 'r';
    }
    else {
        sym = 'R';
    }
}