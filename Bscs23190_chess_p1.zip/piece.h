#pragma once
#include<iostream>
#include "Header.h"
using namespace std;


class pieces {
protected:
	position Pos;
	color Col;
	char sym;
public:

	pieces(position p, color c) {
		Pos = p;
		Col = c;
	}
	void Draw() {
		gotoRowCol(Pos.x, Pos.y);
		cout << sym;
	}

	void unDraw() {
		gotoRowCol(Pos.x, Pos.y);
		cout << " ";
	}
};