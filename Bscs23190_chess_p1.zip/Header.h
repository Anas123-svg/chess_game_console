#pragma once
#include <iostream>
#include<Windows.h>
#include<conio.h>
using namespace std;

struct position {
	int x, y;
};

enum color {
	BLACK,
	White
};

void gotoRowCol(int rpos, int cpos);
/*
void gotoRowCol(int rpos, int cpos)
{
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = cpos;
	scrn.Y = rpos;
	SetConsoleCursorPosition(hOuput, scrn);
}*/