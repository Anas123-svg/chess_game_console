#include "Queen.h"


Queen::Queen(position p, color c):pieces(p,c) {
	sym = ((c == BLACK) ? 'Q' : 'q');
    if (c == BLACK) {
        sym = 'q';
    }
    else {
        sym = 'Q';
    }
}