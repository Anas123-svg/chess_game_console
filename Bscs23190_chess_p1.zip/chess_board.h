#pragma once
#include<iostream>
#include "piece.h"
#include "Pawns.h"
#include "king.h"
#include "Rook.h"
#include "Header.h"
#include "Bishop.h"
#include "Knight.h"
#include "Queen.h"
using namespace std;


class board {
private:
	int dem;
	pieces***Ps;
	//void init();
public:
	board() {
		dem = 8;

	}

	void init() {
		Ps = new pieces ** [8];
		for (int i = 0; i < dem; i++) {
			Ps[i] = new pieces * [8] {};
			for (int j = 0; j < dem; j++) {
				if ((i == 0 && j == 0) || (i == 0 && j == 7) || (i==7 && j==7) || (i==7 && j==0) ) {
					Ps[i][j] = new Rook(position{ i,j }, BLACK);
					if ((i == 7 && j == 7) || (i == 7 && j == 0)) {
						Ps[i][j] = new Rook(position{ i,j }, White);
					}
				}
				else if ((i == 0 && j == 1) || (i == 0 && j == 6) || (i == 7 && j == 6) || (i == 7 && j == 1)) {
					Ps[i][j] = new Knight(position{ i,j }, BLACK);
					if ((i == 7 && j == 6) || (i == 7 && j == 1)) {
						Ps[i][j] = new Knight(position{ i,j }, White);
					}
				}
				else if ((i == 0 && j == 2) || (i == 0 && j == 5) || (i == 7 && j == 5) || (i == 7 && j == 2)) {
					Ps[i][j] = new Bishop(position{ i,j }, BLACK);
					if ((i == 7 && j == 5) || (i == 7 && j == 2)) {
						Ps[i][j] = new Bishop(position{ i,j }, White);
					}

				}
				else if ((i == 0 && j == 3) || (i == 7 && j == 3) ) {
					Ps[i][j] = new king(position{ i,j }, BLACK);
					if ((i == 7 && j == 3)) {
						Ps[i][j] = new king(position{ i,j }, White);
					}
				}
				else if ((i == 0 && j == 4) || (i == 7 && j == 4)) {
					Ps[i][j] = new Queen(position{ i,j }, BLACK);
					if ((i == 7 && j == 4)) {
						Ps[i][j] = new Queen(position{ i,j }, White);
					}
				}
				else if (i == 1) {
					Ps[i][j] = new Pawns(position{ i,j }, BLACK);

				}
				else if (i == 6) {
					Ps[i][j] = new Pawns(position{ i,j }, White);
				}
			}
		}
	}


	void draw() {
		for (int i = 0; i < dem; i++) {
			for (int j = 0; j < 8; j++) {
				if (Ps[i][j] == nullptr && i!=1)
					cout << "-";
				else
					Ps[i][j]->Draw();
			}
			cout << endl;
		}
		
	}
};