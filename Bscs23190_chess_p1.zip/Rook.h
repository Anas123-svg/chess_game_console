#pragma once

#include "Header.h"

#include "piece.h"

class Rook :
    public pieces
{
public:
    Rook(position p, color c);
};

