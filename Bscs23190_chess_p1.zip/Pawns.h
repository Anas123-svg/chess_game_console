#pragma once
#ifndef PAWNS_H
#define PAWNS_H

#include "piece.h"
#include "Header.h"

class Pawns :
    public pieces
{
public:
    Pawns(position p, color c);
};

#endif 
