#pragma once
#ifndef QUEEN_H
#define QUEEN_H
#include "Header.h"
#include "piece.h"

class Queen :
    public pieces
{
public:
    Queen(position p, color c);
};

#endif // !QUEEN_H