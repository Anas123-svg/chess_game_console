#pragma once
#ifndef KNIGHT_H
#define KNIGHT_H
#include "piece.h"
#include "Header.h"
class Knight :
    public pieces
{
public:
    Knight(position p, color c);
};

#endif // !KNIGHT_H
